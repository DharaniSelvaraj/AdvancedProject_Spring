package com.vforum.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.rowset.serial.SerialBlob;

import org.apache.log4j.Logger;
//import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Answers;
import com.vforum.model.Employee;
import com.vforum.model.Questions;
import com.vforum.service.AnswerService;
import com.vforum.service.CategoryService;
import com.vforum.service.EmployeeService;
import com.vforum.service.QuestionService;
@Controller
public class QuestionController {
	Logger log = Logger.getLogger(this.getClass());
	@Autowired
    private EmployeeService employeeService;
    @Autowired
    private QuestionService questionService;
    @Autowired
    private AnswerService answerService;
    @Autowired
    private CategoryService categoryService;
	 @RequestMapping("/addQuestion")    
	    public ModelAndView addQuestion(ModelAndView model,HttpSession session,@RequestParam(value="cId") Integer categoryId){   
		   
		 	try {
		 		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) 
	    		{
					log.info("This is QuestionController postQuestion method Log");
			    	
			    	Employee employee=employeeService.getEmployee(employeeId);
			        model.addObject("employee", employee);
			        model.addObject("categoryId", categoryId);
			        model.setViewName("Question");
	    		}  
			} catch (Exception e) {
				log.error("Error is in QuestionController postQuestion method Log " + e);
			}
	    	return model;
	    }
	 
	    @RequestMapping(value = "/addQuestionProcess", method = RequestMethod.POST)
	    public String addQuestionProcess(HttpSession session,@RequestParam("questionDescription") String questionDescription,@RequestParam(value="categoryId") Integer categoryId,@RequestParam("questionImage") MultipartFile questionImage) {
	    	
	    	String url=null;
	     	try {
	     		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) 
	    		{
					log.info("This is QuestionController addQuestion method Log");
					Questions question=new Questions();
					question.setQuestionDescription(questionDescription);
					
					System.out.println(questionImage);
					if(questionImage.isEmpty()==false) {
						byte[] photoBytes = questionImage.getBytes();
						Blob blob = new SerialBlob(photoBytes);
						question.setQuestionImage(blob);
					}
					else
					{
						question.setQuestionImage(null);
					}
					
					
			    	long milli=System.currentTimeMillis();
					Date currentDate=new Date(milli);
			    	question.setDate(currentDate);
			    	
			    	Employee employee=employeeService.getEmployee(employeeId);
			        question.setEmployee(employee);
			        
			        question.setCategory(categoryService.getCategoryById(categoryId));
					questionService.addQuestion(question);
					url="redirect:homePage";

	    		}
	    	} catch (Exception e) {
				log.error("Error is in QuestionController addQuestion method Log" + e);
			}
	    	return url;
	       
	    }
	    @RequestMapping(value="/getQuestionImage/{id}", method = RequestMethod.GET)    
	    public void getQuestionImage(HttpServletResponse response, @PathVariable("id") int questionId) throws SQLException, IOException 
		{ 
			response.setContentType("image/jpeg");
			Questions question=questionService.getQuestion(questionId);
			if(question.getQuestionImage()!=null) {
			Blob ph =questionService.getQuestionImage(questionId);
			byte[] bytes = ph.getBytes(1, (int) ph.length());
			response.getOutputStream().write(bytes);
			response.getOutputStream().close();
//			InputStream inputStream = new ByteArrayInputStream(bytes);
//			IOUtils.copy(inputStream, response.getOutputStream());
		} }
	 
	    @RequestMapping(value = "/editQuestion", method = RequestMethod.GET)
	    public ModelAndView editQuestion(@RequestParam(value="qid") Integer questionId,HttpSession session) {
	    	ModelAndView model=null;
	     	try {
	     		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) 
	    		{
					log.info("This is QuestionController editQuestion method Log");
			        Questions question = questionService.getQuestion(questionId);
			        model = new ModelAndView();
			        model.addObject("question", question);
			        System.out.println("edit ques"+question.getQuestionDescription());
			        model.setViewName("editQuestion");
	    		}
	    	} catch (Exception e) {
				log.error("Error is in QuestionController editQuestion method Log " + e);
		}
	    	return model;
	    }
	   
	    @RequestMapping(value = "/editQuestionProcess", method = RequestMethod.POST)
	    public String editQuestionProcess(HttpSession session,@RequestParam("questionDescription") String questionDescription,
	    		@RequestParam(value="questionId") Integer questionId,@RequestParam("questionImage") MultipartFile questionImage) {
	     	
	     	String url=null;
	    	try {
	     		Integer employeeId=(Integer) session.getAttribute("employeeId");
	     		Questions question=questionService.getQuestion(questionId);
	    		if(employeeId!=null) 
	    		{
					log.info("This is QuestionController editQuestionProcess method Log");
					System.out.println("date"+question.getDate());
					System.out.println("ques desc  "+question.getQuestionDescription());
					System.out.println("questionid   "+ question.getQuestionId());
					question.setQuestionDescription(questionDescription);
					if(questionImage.isEmpty()==false) {
						byte[] photoBytes = questionImage.getBytes();
						Blob blob = new SerialBlob(photoBytes);
						question.setQuestionImage(blob);
					}
					
					questionService.editQuestion(question);
					url="redirect:homePage";
		        }
	    	} catch (Exception e) {
				log.error("Error is in QuestionController editQuestionProcess method Log " + e);
			}
	    	return url;
	    }
	    
	
	    @RequestMapping(value = "/deleteQuestion", method = RequestMethod.GET)
	    public String deleteQuestion(@RequestParam(value="qid") Integer questionId,HttpSession session) {
	     
	    	String url=null;
	     	try {
	     		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) 
	    		{
					log.info("This is QuestionController deleteQuestion method Log");
			        Questions question = questionService.getQuestion(questionId);
			        List<Answers> answerList=answerService.getAnswersByQuestionId(questionId);
			        for(Answers ans:answerList) {
			        	answerService.deleteAnswer(ans);
			        }
			        questionService.deleteQuestion(question);
			        url="redirect:homePage";
	    		}
	    	} catch (Exception e) {
				log.error("Error is in QuestionController deleteQuestion method Log" + e);
			}
	    	return url;
	    }
	    @RequestMapping(value = "/viewMyQuestion", method = RequestMethod.GET)
	    public ModelAndView viewMyQuestion(HttpSession session) {
	    	ModelAndView model=null;
	     	try {
	     		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) 
	    		{
				log.info("This is QuestionController viewQuestion method Log");
				model = new ModelAndView();
				Employee employee=employeeService.getEmployee(employeeId);
			    model.addObject("employee",employee);
				List<Questions> allQuestions=questionService.getAllQuestionByEmployee(employeeId);
				model.addObject("allQuestions",allQuestions);
				model.setViewName("MyQuestions");
				List<Answers> allAnswers=answerService.getAllAnswers();
			    model.addObject("allAnswers",allAnswers);
	    		}
	    	} catch (Exception e) {
				log.error("Error is in QuestionController viewQuestion method Log" + e);
			}
	    	return model;
	    }
	   
}
