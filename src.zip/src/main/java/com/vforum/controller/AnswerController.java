package com.vforum.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.rowset.serial.SerialBlob;

import org.apache.log4j.Logger;
//import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Answers;
import com.vforum.model.Employee;
import com.vforum.model.Questions;
import com.vforum.service.AnswerService;
import com.vforum.service.EmployeeService;
import com.vforum.service.QuestionService;

@Controller
public class AnswerController {

	
		Logger log = Logger.getLogger(this.getClass());
		@Autowired
	    private EmployeeService employeeService;
	    @Autowired
	    private AnswerService answerService;
	    @Autowired
	    private QuestionService questionService;
	    
	    @RequestMapping(value ="/addAnswer", method = RequestMethod.GET)    
	    public ModelAndView addAnswer(ModelAndView model,HttpSession session,@RequestParam(value="qid") Integer questionId){ 
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is in AnswerController postAnswer method ");
			    	Questions question=questionService.getQuestion(questionId);
			    	Employee employee=employeeService.getEmployee(employeeId);
			        model.addObject("employee", employee);
			    	model.addObject("question", question);
			        model.setViewName("Answer");
	    		    				}
		 		} catch (Exception e) {
				log.error("Error is in AnswerController postAnswer method  " + e);
		 		}
	    	return model;
	    }
	 
	    @RequestMapping(value = "/addAnswerProcess", method = RequestMethod.POST)
	    public String addAnswerProcess(HttpSession session,@RequestParam("answerDescription") String answerDescription,
	    		@RequestParam(value="questionId") Integer questionId,@RequestParam("answerImage") MultipartFile answerImage) {
	    	String url=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					
					log.info("This is AnswerController addAnswer method ");
					Answers answer=new Answers();
			        answer.setAnswerDescription(answerDescription);
			        
			    	long milli=System.currentTimeMillis();
					Date currentDate=new Date(milli);
			    	answer.setDate(currentDate);
			    	
			    	if(answerImage.isEmpty()==true)
			    	{
			    		answer.setAnswerImage(null);
			    	}
			    	else
			    	{
				    	byte[] photoBytes = answerImage.getBytes();
						Blob blob = new SerialBlob(photoBytes);
						answer.setAnswerImage(blob);
			    	}
					
			    	Questions question=questionService.getQuestion(questionId);
			    	answer.setQuestion(question);
			    	
			    	Employee employee=employeeService.getEmployee(employeeId);
			        answer.setEmployee(employee);
			        
			    	answerService.addAnswer(answer);
			    	url="redirect:homePage";
	    		}
	    	} catch (Exception e) {
				log.error("Error is in AnswerController addAnswer method " + e);
			}
	    	return url;
	       
	    }
	    
	    @RequestMapping(value="/getAnswerImage/{id}", method = RequestMethod.GET)    
	    public void getAnswerImage(HttpServletResponse response, @PathVariable("id") int answerId) throws SQLException, IOException 
		{ 
			response.setContentType("image/jpeg");
			Answers answer=answerService.getAnswer(answerId);
			if(answer.getAnswerImage()!=null) {
			Blob ph =answerService.getAnswerImage(answerId);
			byte[] bytes = ph.getBytes(1, (int) ph.length());
			response.getOutputStream().write(bytes);
			response.getOutputStream().close();
//			InputStream inputStream = new ByteArrayInputStream(bytes);
//			IOUtils.copy(inputStream, response.getOutputStream());
		} 
		}
	    
	    @RequestMapping(value = "/editAnswer", method = RequestMethod.GET)
	    public ModelAndView editAnswer(@RequestParam(value="aid") Integer answerId,HttpSession session) {
	    	ModelAndView model =null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is AnswerController editAnswer method ");
			        Answers answer = answerService.getAnswer(answerId);
			        model = new ModelAndView();
			        model.addObject("answer", answer);
			        model.setViewName("editAnswer");
	    		}
		        
	    	} catch (Exception e) {
				log.error("Error is in AnswerController editAnswer method " + e);
			}
	    	return model;
	    }
	   
	    @RequestMapping(value = "/editAnswerProcess", method = RequestMethod.POST)
	    public String editAnswerProcess(HttpSession session,@RequestParam("answerDescription") String answerDescription,
	    		@RequestParam(value="answerId") Integer answerId,@RequestParam("answerImage") MultipartFile answerImage) {
	    	
	    	
	    	String url=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		Answers answer=answerService.getAnswer(answerId);
	    		if(employeeId!=null) {
	    			
					log.info("This is AnswerController postAnswer method ");
					answer.setAnswerDescription(answerDescription);
					if(answerImage.isEmpty()==false) {
						byte[] photoBytes = answerImage.getBytes();
						Blob blob = new SerialBlob(photoBytes);
						answer.setAnswerImage(blob);
					}
					answerService.editAnswer(answer);
					url="redirect:homePage";
	    		}
	       
	    	} catch (Exception e) {
				log.error("Error is in AnswerController postAnswer method " + e);
			}
	    	 return url;
	    }
	    @RequestMapping(value = "/deleteAnswer", method = RequestMethod.GET)
	    public String deleteAnswer(@RequestParam(value="aid") Integer answerId,HttpSession session) {
	      
	    	String url=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is AnswerController postAnswer method ");
			        Answers answer = answerService.getAnswer(answerId);
			        answerService.deleteAnswer(answer);
			        url="redirect:homePage";
	    		}
			        
	    	} catch (Exception e) {
				log.error("Error is in AnswerController postAnswer method " + e);
			}
	    	return url;
	    }
	    @RequestMapping(value = "/viewMyAnswer", method = RequestMethod.GET)
	    public ModelAndView viewMyAnswer(HttpSession session) {
	    	ModelAndView model=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is AnswerController viewMyAnswer method ");
					
				    model = new ModelAndView();
				    Employee employee=employeeService.getEmployee(employeeId);
				    model.addObject("employee",employee);
				    List<Questions> allQuestions=questionService.getAllQuestions();
			        model.addObject("allQuestions",allQuestions);
			     	List<Answers> allAnswers=answerService.getAnswersByEmployee(employeeId);
			        model.addObject("allAnswers",allAnswers);
			        model.setViewName("MyAnswers");
	    							}
	    	} catch (Exception e) {
				log.error("Error is in AnswerController viewMyAnswer method " + e);
			}
	        return model;
	    }
	   
	    
	    @RequestMapping(value = "/viewAnswers", method = RequestMethod.GET)
	    public ModelAndView viewAnswers(HttpSession session,@RequestParam(value="qid") Integer questionId) {
	    	ModelAndView model=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		
	    		if(employeeId!=null) {
					log.info("This is AnswerController viewAnswer method ");
				    model = new ModelAndView();
				    Employee employee=employeeService.getEmployee(employeeId);
				    model.addObject("employee",employee);
				    Questions question=questionService.getQuestion(questionId);
				    model.addObject("question",question);
			     	List<Answers> allAnswers=answerService.getAnswersByQuestionId(questionId);
			        model.addObject("allAnswers",allAnswers);
			        model.setViewName("ViewAnswers");
	    							}
	    	} catch (Exception e) {
				log.error("Error is in AnswerController viewAnswer method " + e);
			}
	        return model;
	    }

}