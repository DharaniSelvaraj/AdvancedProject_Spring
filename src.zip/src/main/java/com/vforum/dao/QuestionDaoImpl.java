package com.vforum.dao;

import java.sql.Blob;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.vforum.model.Questions;
@Repository
public class QuestionDaoImpl implements QuestionDao {
	Logger log = Logger.getLogger(this.getClass());

	 @Autowired
	    private SessionFactory sessionFactory;
	 
	   
	public void addQuestion(Questions question) {
		try {
			log.info("This is QuestionDaoImpl addQuestion method Log");
		    sessionFactory.getCurrentSession().save(question);
		} catch (Exception e) {
			log.error("Error is in QuestionDaoImpl addQuestion method Log" + e);
		}
	}

	public Questions getQuestion(int questionId) {
		Questions question=null;
		try {
			log.info("This is QuestionDaoImpl getQuestion method Log");
		    question= (Questions) sessionFactory.getCurrentSession().get(
            Questions.class, questionId);
		} catch (Exception e) {
			log.error("Error is in QuestionDaoImpl getQuestion method Log " + e);
		}
		return question; 
	}
	
	public void editQuestion(Questions question) {
		try {
			log.info("This is QuestionDaoImpl editQuestion method Log");
			 sessionFactory.getCurrentSession().update(question);

		} catch (Exception e) {
			log.error("Error is in QuestionDaoImpl editQuestion method Log " + e);
		}
	}
	
	public void deleteQuestion(Questions question) {
		try {
			log.info("This is QuestionDaoImpl deleteQuestion method Log");
			sessionFactory.getCurrentSession().delete(question);

		} catch (Exception e) {
			log.error("Error is in QuestionDaoImpl deleteQuestion method Log" + e);
		}
	}
	
	
	@SuppressWarnings({ "unchecked" })
    public List<Questions> getAllQuestions() {
		List<Questions> allQuestions=null;
		try {
			log.info("This is QuestionDaoImpl getAllQuestions method Log");
			allQuestions= sessionFactory.getCurrentSession().createQuery("select q from Questions q  order by questionId desc")
                .list();
		} catch (Exception e) {
			log.error("Error is in QuestionDaoImpl getAllQuestions method Log " + e);
		}
		return allQuestions;
    }

	
	@SuppressWarnings("unchecked")
	public List<Questions> getAllQuestionByCategory(int categoryId) {
		List<Questions> allQuestions=null;

		try {
			log.info("This is QuestionDaoImpl getAllQuestionByCategory method Log");
			allQuestions=sessionFactory.getCurrentSession().createQuery("from Questions q where categoryId="+categoryId+"order by questionId desc") .list();
		} catch (Exception e) {
			log.error("Error is in QuestionDaoImpl getAllQuestionByCategory method Log " + e);
		}
		return allQuestions;
	}
	
	@SuppressWarnings("unchecked")
	public List<Questions> getAllQuestionByEmployee(int employeeId) {
		List<Questions> allQuestions=null;

		try {
			log.info("This is QuestionDaoImpl getAllQuestionByEmployee method Log");
			allQuestions=sessionFactory.getCurrentSession().createQuery("from Questions q where employeeId="+employeeId+"order by questionId desc") .list();
		} catch (Exception e) {
			log.error("Error is in QuestionDaoImpl getAllQuestionByEmployee method Log " + e);
		}
		return allQuestions;
	}

	@Override
	public Blob getQuestionImage(int questionId) {
		List<Blob> questionImages =sessionFactory.getCurrentSession().createQuery("select q.questionImage from Questions q where questionId ="+questionId).list();
		return questionImages.get(0);
	}
}